# Trust Browser Extension
A client interface for issuing Trust
